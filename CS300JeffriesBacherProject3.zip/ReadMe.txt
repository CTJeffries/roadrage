Colby Jeffries and Tommy Bacher
CS300 - Project 3 ReadMe

When compiling, ensure to link OpenGL, tgaClass.cpp, glm.cpp, and math (if on Linux?).

// Controls:
//  w: Accelerator
//  s: Brake/Reverse
//  a: Turn Left
//  d: Turn Right
//  v: Toggle view modes.
//  h: Toggles horror mode. (THICK FOG).

Right click to open the menu. Here you can change the amount of trees, the amount of bike men and
reset the game.
